<?php

require_once('AscueException.php');
require_once('Db.php');
require_once('DbUtils.php');
require_once('DbArrayParser.php');
require_once('Xml.php');
require_once('Schedule.php');
require_once('ChirpStackApi.php');

class AscueApi
{
    const CMD_CREATE_UPDATE_DEVICE = 1;
    const CMD_DELETE_DEVICE = 2;

    const CMD_CREATE_UPDATE_TASK_RT = 10;
    const CMD_CREATE_UPDATE_TASK_SCHEDULE = 11;
    const CMD_DELETE_TASK = 12;
    const CMD_DISABLE_TASK = 13;

    const CMD_GET_NEW_RESULTS = 20;
    const CMD_GET_RESULT = 21;

    const TASK_STATE_ENABLED = 1;
    const TASK_STATE_DISABLED = 2;
    const TASK_STATE_DELETED = 3;

    const TASK_TYPE_SCHEDULE = 1;
    const TASK_TYPE_RT = 2;

    const RESULT_TYPE_SERVER_EVENT = 1;
    const RESULT_TYPE_RT = 2;
    const RESULT_TYPE_ENERGY = 3;
    const RESULT_TYPE_POWER_PROFILE = 4;
    const RESULT_TYPE_CURRENT_VALUES = 5;
    const RESULT_TYPE_OTHER = 6;

    private $xml;
    private $clientId;
    private $cmd;
    private $request;

    public function AscueApi()
    {
        Db::init();
        $this->xml = new Xml();
    }

    public function proceed()
    {
        $this->parsePost();

        switch ($this->cmd)
        {
        case self::CMD_CREATE_UPDATE_DEVICE:
            $this->createUpdateDevice();
            break;

        case self::CMD_DELETE_DEVICE:
            $this->deleteDevice();
            break;

        case self::CMD_CREATE_UPDATE_TASK_RT:
        case self::CMD_CREATE_UPDATE_TASK_SCHEDULE:
            $this->createUpdateTask();
            break;

        case self::CMD_DELETE_TASK:
        case self::CMD_DISABLE_TASK:
            $this->deleteTask();
            break;

        case self::CMD_GET_NEW_RESULTS:
        case self::CMD_GET_RESULT:
            return $this->getResults();

        default:
            throw new AscueException(AscueError::UNKNOWN_CMD);
        }

        return $this->xml->createErrorXml(AscueError::OK);
    }

    private function parsePost()
    {
        if (!isset($_POST['token']) || !isset($_POST['cmd']) || !isset($_POST['data']))
        {
            throw new AscueException(AscueError::UNCORRECT_REQUEST);
        }

        $this->authClient($_POST['token']);
        $this->cmd = $_POST['cmd'];
        $this->request = $this->xml->parse($_POST['data']);

        if (!$this->request)
        {
            throw new AscueException(AscueError::UNCORRECT_REQUEST);
        }
    }

    private function authClient($token)
    {
        $token = Db::quote($token);

        $sql = "
        SELECT id
        FROM client
        WHERE token = $token";

        Db::query($sql);
        $result = Db::getAssocAll();

        if (!$result)
        {
            throw new AscueException(AscueError::DATA_EXCHANGE_ERROR);
        }

        $this->clientId = $result[0]['id'];
    }

    private function validateDevice()
    {
        if (!$this->request->device)
        {
            throw new AscueException(AscueError::UNCORRECT_REQUEST, 'В запросе должно быть устройство');
        }

        $device = $this->request->device;

        if (!$device->externalId)
        {
            throw new AscueException(AscueError::UNCORRECT_REQUEST, 'Не передан идентификатор устройства');
        }

        if (!$device->pgroups)
        {
            throw new AscueException(AscueError::UNCORRECT_REQUEST, 'Не переданы группы параметров');
        }

        if ($this->cmd == self::CMD_CREATE_UPDATE_DEVICE && count($device->pgroups) != 1)
        {
            throw new AscueException(AscueError::UNCORRECT_REQUEST, 'У устройства должна быть одна группа параметров');
        }

        foreach ($device->pgroups as $pgroup)
        {
            if (!$pgroup->parameters)
            {
                throw new AscueException(AscueError::UNCORRECT_REQUEST, 'Группа параметров не содержит параметры');
            }

            foreach ($pgroup->parameters as $parameter)
            {
                if (!$parameter->id || !is_numeric($parameter->id))
                {
                    throw new AscueException(AscueError::UNCORRECT_REQUEST, 'Некорректный идентификатор параметра');
                }
            }
        }
    }

    private function createUpdateDevice()
    {
        $this->validateDevice();
        $device = $this->request->device;

        if (!$device->externalUspdId && (!is_numeric($device->classId) || !is_numeric($device->connClassId)))
        {
            throw new AscueException(AscueError::UNCORRECT_REQUEST, 'Не указано УСПД или передан некорректный класс устройства');
        }

        $externalId = Db::quote($device->externalId);

        if ($device->externalUspdId)
        {
            $uspdId = $this->getDeviceId($device->externalUspdId);

            if ($uspdId === false)
            {
                throw new AscueException(AscueError::UNKNOWN_DEVICE, 'УСПД не существует');
            }
            $classId = 'NULL';
            $connClassId = 'NULL';
        }
        else
        {
            // если не задан УСПД, то указываем классы устройств
            $uspdId = 'NULL';
            $classId = Db::quote($device->classId);
            $connClassId = Db::quote($device->connClassId);
        }

        $timezone = Db::quote($device->timezone ?? 'Europe/Moscow');
        $parameters = DbUtils::createParametersArray($device->pgroups[0]->parameters);

        if (!$this->isTimezoneExists($timezone))
        {
            throw new AscueException(AscueError::UNCORRECT_REQUEST, 'Некорректный часовой пояс');
        }

        $deviceId = $this->getDeviceId($device->externalId);
        $sql = '';

        if ($deviceId === false)
        {
            $sql = "
            INSERT INTO
                device
                (external_id, class_id, conn_class_id, uspd_id, timezone, parameters, client_id, deleted) 
            VALUES ($externalId, $classId, $connClassId, $uspdId, $timezone, $parameters, {$this->clientId}, FALSE)";
        }
        else
        {
            $sql = "
            UPDATE
                device
            SET
                class_id = $classId,
                conn_class_id = $connClassId,
                uspd_id = $uspdId,
                timezone = $timezone,
                parameters = $parameters,
                deleted = FALSE
            WHERE
                id = $deviceId";
        }

        Db::query($sql);

        $chirpStack = new ChirpStackApi();
        $chirpStack->sync($device);
    }

    private function createUpdateTask()
    {
        if (!$this->request->externalId)
        {
            throw new AscueException(AscueError::UNCORRECT_REQUEST, 'Не передан идентификатор задания');
        }

        $this->validateDevice();

        $device = $this->request->device;
        $pgroup = $device->pgroups[0];
        $deviceId = $this->getDeviceId($device->externalId);

        if ($deviceId === false)
        {
            throw new AscueException(AscueError::UNKNOWN_DEVICE, 'Устройство не существует');
        }

        $externalId = Db::quote($this->request->externalId);
        $timeValues = 'NULL';
        $timeInterval = 'NULL';
        $days = 'NULL';
        $daysOfWeek = 'NULL';
        $type = $this->cmd == self::CMD_CREATE_UPDATE_TASK_RT ? self::TASK_TYPE_RT : self::TASK_TYPE_SCHEDULE;

        if ($type == self::TASK_TYPE_SCHEDULE)
        {
            if (!$this->request->time)
            {
                throw new AscueException(AscueError::UNCORRECT_REQUEST, 'Не передано расписание');
            }

            $schedule = new Schedule();
            $schedule->parse($this->request->time);

            $timeValues = DbUtils::createArray($schedule->timeValues);

            if ($schedule->timeInterval)
            {
                $timeInterval = Db::quote($schedule->timeInterval);
            }
            if ($schedule->days)
            {
                $days = DbUtils::createArray($schedule->days);
            }
            if ($schedule->daysOfWeek)
            {
                $daysOfWeek = DbUtils::createArray($schedule->daysOfWeek);
            }
        }

        $taskId = $this->getTaskId($this->request->externalId);
        $sql = '';

        if ($taskId === false)
        {
            $parameters = DbUtils::createParametersArray($pgroup->parameters);

            $sql = "
            INSERT INTO
                task
                (external_id, device_id, parameters, type, next_execution_time,
                    time_values, time_interval, days, days_of_week,
                    execute_when_connected, client_id, state) 
            VALUES ($externalId, $deviceId, $parameters, $type, " . ($type == self::TASK_TYPE_SCHEDULE ? 'NULL' : 'NOW()') . ",
                        $timeValues, $timeInterval, $days, $daysOfWeek,
                        FALSE, {$this->clientId}, ".self::TASK_STATE_ENABLED.")";

            Db::query($sql);
            return;
        }

        if ($this->getTaskState($taskId) != self::TASK_STATE_DELETED &&
            $pgroup->isParameterExists(Parameter::AUTO_DATETIME_UI))
        {
            $beginDateTime = $this->getTaskBeginDateTime($taskId);

            if ($beginDateTime !== false)
            {
                $pgroup->setParameterValue(Parameter::BEGIN_DATETIME_S, $beginDateTime);
            }
        }

        $parameters = DbUtils::createParametersArray($pgroup->parameters);

        $sql = "
        UPDATE
            task
        SET
            device_id = $deviceId,
            parameters = $parameters,
            type = $type,
            next_execution_time = " . ($type == 1 ? 'NULL' : 'NOW()') . ",
            time_values = $timeValues,
            time_interval = $timeInterval,
            days = $days,
            days_of_week = $daysOfWeek,
            state = ".self::TASK_STATE_ENABLED."
        WHERE
            id = $taskId";

        Db::query($sql);
    }

    private function deleteDevice()
    {
        if (!$this->request->device)
        {
            throw new AscueException(AscueError::UNCORRECT_REQUEST, 'В запросе должно быть устройство');
        }

        $device = $this->request->device;

        if (!$device->externalId)
        {
            throw new AscueException(AscueError::UNCORRECT_REQUEST, 'Не передан идентификатор устройства');
        }

        $deviceId = $this->getDeviceId($device->externalId);

        if ($deviceId === false)
        {
            return;
        }

        // удаляем устройство
        $sql = "
        UPDATE
            device
        SET
            deleted = TRUE
        WHERE
            id = $deviceId";

        Db::query($sql);
    }

    private function deleteTask()
    {
        if (!$this->request->externalId)
        {
            throw new AscueException(AscueError::UNCORRECT_REQUEST, 'Не передан идентификатор задания');
        }

        $taskId = $this->getTaskId($this->request->externalId);

        if ($taskId === false)
        {
            return;
        }

        $sql = "
        UPDATE
            task
        SET
            execute_when_connected = FALSE,
            state = " . ($this->cmd == self::CMD_DELETE_TASK ? self::TASK_STATE_DELETED : self::TASK_STATE_DISABLED) . "
        WHERE
            id = $taskId";

        Db::query($sql);
    }

    private function getResults()
    {
        if (!is_numeric($this->request->id))
        {
            throw new AscueException(AscueError::UNCORRECT_REQUEST, 'Передан некорректный идентификатор последнего запроса');
        }

        $id = Db::quote($this->request->id);

        $sql = "
        SELECT
            request.id AS request_id,
            request.time_end AS time,
            task.external_id AS task_external_id,
            device.external_id AS device_external_id,
            request.parameters AS parameters
        FROM
            request
        LEFT JOIN
            task
        ON
            request.task_id = task.id
        LEFT JOIN
            device
        ON
            task.device_id = device.id
        WHERE";

        if ($this->cmd == self::CMD_GET_NEW_RESULTS)
        {
            switch ($this->request->type)
            {
            case null:
                $sql .= "
                (
                    request.client_id = {$this->clientId} OR
                    request.client_id IS NULL
                )";
                break;

            case self::RESULT_TYPE_SERVER_EVENT:
                $sql .= "
                (
                    request.client_id = {$this->clientId} OR
                    request.client_id IS NULL
                )
                AND request.task_id IS NULL";
                break;

            case self::RESULT_TYPE_RT:
                $sql .= "
                request.client_id = {$this->clientId}
                AND task.type = ".self::TASK_TYPE_RT;
                break;

            case self::RESULT_TYPE_ENERGY:
                $sql .= "
                request.client_id = {$this->clientId}
                AND task.type = ".self::TASK_TYPE_SCHEDULE."
                AND '{\"(10,1)\", \"(10,4)\", \"(10,5)\", \"(10,13)\", \"(10,20)\"}' && request.parameters";
                break;

            case self::RESULT_TYPE_POWER_PROFILE:
                $sql .= "
                request.client_id = {$this->clientId}
                AND task.type = ".self::TASK_TYPE_SCHEDULE."
                AND '{\"(10,3)\"}' && request.parameters";
                break;

            case self::RESULT_TYPE_CURRENT_VALUES:
                $sql .= "
                request.client_id = {$this->clientId}
                AND task.type = ".self::TASK_TYPE_SCHEDULE."
                AND '{\"(10,2)\", \"(10,22)\"}' && request.parameters";
                break;

            case self::RESULT_TYPE_OTHER:
                $sql .= "
                request.client_id = {$this->clientId}
                AND task.type = ".self::TASK_TYPE_SCHEDULE."
                AND NOT '{\"(10,1)\", \"(10,2)\", \"(10,3)\", \"(10,4)\", \"(10,5)\", \"(10,13)\", \"(10,20)\", \"(10,22)\"}' && request.parameters";
                break;

            default:
                throw new AscueException(AscueError::UNCORRECT_REQUEST, 'Передан некорректный тип ответа');
            }

            if ($this->request->id)
            {
                $sql .= "
                AND request.id > $id";
            }

            $sql .= "
            ORDER BY
                request.id
            LIMIT 500";
        }
        else
        {
            $sql .= "
            request.client_id = {$this->clientId}
            AND request.id = $id";
        }

        Db::query($sql);

        $rows = Db::getAssocAll();
        $requests = [];
        $dbArrayParser = new DbArrayParser();

        foreach ($rows as $row)
        {
            $request = new RequestData();
            $request->id = $row['request_id'];
            $request->time = substr($row['time'], 0, 19); // время без долей секунды
            $request->externalId = $row['task_external_id'];

            $request->device = new DeviceData();
            $request->device->externalId = $row['device_external_id'];
            $request->device->pgroups = $dbArrayParser->parse($row['parameters']);

            $requests[] = $request;
        }

        return $this->xml->createXml($requests);
    }

    private function getDeviceId($externalId)
    {
        $externalId = Db::quote($externalId);

        $sql = "
        SELECT id
        FROM device
        WHERE external_id = $externalId AND client_id = {$this->clientId}";

        Db::query($sql);
        $result = Db::getAssocAll();

        return !$result ? false : $result[0]['id'];
    }

    private function getTaskId($externalId)
    {
        $externalId = Db::quote($externalId);

        $sql = "
        SELECT id
        FROM task
        WHERE external_id = $externalId AND client_id = {$this->clientId}";

        Db::query($sql);
        $result = Db::getAssocAll();

        return !$result ? false : $result[0]['id'];
    }

    /**
     * Возвращает время, с которого начнется чтение данных при очередном выполнении задачи,
     * в случае, если установлен флаг автоматического расчета времени начала.
     */
    private function getTaskBeginDateTime($id)
    {
        $sql = "
        SELECT
            p.id AS id,
            p.value AS value
        FROM
            task,
            unnest(parameters) AS p
        WHERE
            task.id = $id AND
            (
                p.id = ".Parameter::BEGIN_DATETIME_S." OR
                p.id = ".Parameter::AUTO_DATETIME_UI."
            )";

        Db::query($sql);
        $rows = Db::getAssocAll();

        $hasAutoDateTime = false;

        foreach ($rows as $row)
        {
            if ($row['id'] == Parameter::AUTO_DATETIME_UI)
            {
                $hasAutoDateTime = true;
                break;
            }
        }

        if (!$hasAutoDateTime)
        {
            return false;
        }

        foreach ($rows as $row)
        {
            if ($row['id'] == Parameter::BEGIN_DATETIME_S)
            {
                return $row['value'];
            }
        }

        return false;
    }

    private function getTaskState($id)
    {
        $sql = "
        SELECT
            state
        FROM
            task
        WHERE
            id = $id";

        Db::query($sql);
        $result = Db::getAssocAll();

        return !$result ? false : $result[0]['state'];
    }

    private function isTimezoneExists($timezone)
    {
        $sql = "
        SELECT 1
        FROM pg_timezone_names
        WHERE lower(name) = lower($timezone)";

        Db::query($sql);

        return Db::getAssocAll() !== [];
    }
}
