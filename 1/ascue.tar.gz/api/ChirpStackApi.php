<?php

require_once('AscueException.php');
require_once('Parameter.php');
require_once('Config.php');

class ChirpStackApi
{
    const METHOD_GET = 'GET';
    const METHOD_POST = 'POST';
    const METHOD_PUT = 'PUT';


    public function sync($deviceData)
    {
        $pgroup = $deviceData->pgroups[0];

        if (!$pgroup->isParameterExists(Parameter::LORA_DEV_EUI_S))
        {
            // если нет devEui, то это не устройство LoRaWAN
            return false;
        }

        if (!$pgroup->isParameterExists(Parameter::LORA_APP_KEY_S) ||
            !$pgroup->isParameterExists(Parameter::LORA_DEVICE_CLASS) ||
            !$pgroup->isParameterExists(Parameter::LORA_GROUP_NAME))
        {
            throw new AscueException(AscueError::UNCORRECT_PARAMETER, 'Переданы не все параметры');
        }

        $devEui = $pgroup->getParameterValue(Parameter::LORA_DEV_EUI_S);
        $appKey = $pgroup->getParameterValue(Parameter::LORA_APP_KEY_S);
        $deviceClass = $pgroup->getParameterValue(Parameter::LORA_DEVICE_CLASS);
        $groupName = $pgroup->getParameterValue(Parameter::LORA_GROUP_NAME);

        if (!array_key_exists($groupName, Config::CHIRPSTACK_DEVICE_PROFILE_IDS))
        {
            throw new AscueException(AscueError::UNCORRECT_PARAMETER, 'Передана неизвестная группа устройств LoRaWAN');
        }

        if ($deviceClass != 'A' && $deviceClass != 'C')
        {
            throw new AscueException(AscueError::UNCORRECT_PARAMETER, 'Передан некорректный класс устройства LoRaWAN');
        }

        // параметры для ABP должны или отсутствовать или присутствовать все сразу
        $hasDevAddr = $pgroup->isParameterExists(Parameter::LORA_DEV_ADDR_S);
        $hasAppSKey = $pgroup->isParameterExists(Parameter::LORA_APP_S_KEY_S);
        $hasNwkSKey = $pgroup->isParameterExists(Parameter::LORA_NWK_S_KEY_S);

        if (($hasDevAddr || $hasAppSKey || $hasNwkSKey) &&
            !($hasDevAddr && $hasAppSKey && $hasNwkSKey))
        {
            throw new AscueException(AscueError::UNCORRECT_PARAMETER, 'Переданы не все параметры ABP');
        }

        $devAddr = $pgroup->getParameterValue(Parameter::LORA_DEV_ADDR_S);
        $appSKey = $pgroup->getParameterValue(Parameter::LORA_APP_S_KEY_S);
        $nwkSKey = $pgroup->getParameterValue(Parameter::LORA_NWK_S_KEY_S);

        $useAbp = $hasDevAddr && isset(Config::CHIRPSTACK_DEVICE_PROFILE_IDS[$groupName]['ABP']);

        $device = $this->getDevice($devEui);
        $deviceKeys = $device !== null ? $this->getDeviceKeys($devEui) : null;
        $activation = $useAbp && $device !== null ? $this->getActivation($devEui) : null;

        if ($device !== null && $deviceKeys !== null && (!$useAbp || $activation !== null))
        {
            // все параметры есть

            if ($this->needToUpdateDevice($device, $deviceClass, $groupName) ||
                $this->needToUpdateDeviceKeys($deviceKeys, $appKey) ||
                ($useAbp && $this->needToActivate($activation, $devAddr, $appSKey, $nwkSKey)))
            {
                // необходимо обновление
                if ($device['device']['lastSeenAt'])
                {
                    throw new AscueException(AscueError::DATA_EXCHANGE_ERROR,
                        'Невозможно изменить настройки устройства, выходившего на связь');
                }
            }
            else
            {
                // обновлять ничего не требуется
                return true;
            }
        }

        $this->createUpdateDevice($devEui, $useAbp ? 'ABP' : $deviceClass, $groupName, $device === null);

        $this->createUpdateDeviceKeys($devEui, $appKey, $deviceKeys === null);

        if ($useAbp)
        {
            $this->activate($devEui, $devAddr, $appSKey, $nwkSKey);
            $this->createUpdateDevice($devEui, $deviceClass, $groupName, false);
        }

        return true;
    }


    private function getDevice($devEui)
    {
        $response = $this->sendHttpRequest('/api/devices/'.$devEui, self::METHOD_GET, null, true);

        if ($response['code'] !== 200)
        {
            return null;
        }

        return json_decode($response['response'], true);
    }


    private function createUpdateDevice($devEui, $deviceClass, $groupName, $create = true)
    {
        $parameters = [
            'device' => [
                'applicationID' => $groupName,
                'description' => $devEui,
                'devEUI' => $devEui,
                'deviceProfileID' => Config::CHIRPSTACK_DEVICE_PROFILE_IDS[$groupName][$deviceClass],
                'isDisabled' => false,
                'name' => $devEui,
                'skipFCntCheck' => true,
            ],
        ];

        if ($create)
        {
            $this->sendHttpRequest('/api/devices', self::METHOD_POST, json_encode($parameters));
        }
        else
        {
            $this->sendHttpRequest('/api/devices/'.$devEui, self::METHOD_PUT, json_encode($parameters));
        }
    }


    private function needToUpdateDevice($device, $deviceClass, $groupName)
    {
        return $device['device']['applicationID'] != $groupName ||
            $device['device']['deviceProfileID'] != Config::CHIRPSTACK_DEVICE_PROFILE_IDS[$groupName][$deviceClass] ||
            $device['device']['isDisabled'] != false ||
            $device['device']['skipFCntCheck'] != true;
    }


    private function getDeviceKeys($devEui)
    {
        $response = $this->sendHttpRequest('/api/devices/'.$devEui.'/keys', self::METHOD_GET, null, true);

        if ($response['code'] !== 200)
        {
            return null;
        }

        return json_decode($response['response'], true);
    }


    private function createUpdateDeviceKeys($devEui, $appKey, $create = true)
    {
        $parameters = [
            'deviceKeys' => [
                'nwkKey' => $appKey,
                'devEUI' => $devEui,
            ],
        ];

        $this->sendHttpRequest(
            '/api/devices/'.$devEui.'/keys',
            $create ? self::METHOD_POST : self::METHOD_PUT,
            json_encode($parameters)
        );
    }


    private function needToUpdateDeviceKeys($deviceKeys, $appKey)
    {
        return strtoupper($deviceKeys['deviceKeys']['nwkKey']) != strtoupper($appKey);
    }


    private function getActivation($devEui)
    {
        $response = $this->sendHttpRequest('/api/devices/'.$devEui.'/activation', self::METHOD_GET, null, true);

        if ($response['code'] !== 200)
        {
            return null;
        }

        return json_decode($response['response'], true);
    }


    private function activate($devEui, $devAddr, $appSKey, $nwkSKey)
    {
        $parameters = [
            'deviceActivation' => [
                'aFCntDown' => 0,
                'appSKey' => $appSKey,
                'devAddr' => $devAddr,
                'devEUI' => $devEui,
                'fCntUp' => 0,
                'fNwkSIntKey' => $nwkSKey,
                'nFCntDown' => 0,
                'nwkSEncKey' => $nwkSKey,
                'sNwkSIntKey' => $nwkSKey,
            ],
        ];

        $this->sendHttpRequest('/api/devices/'.$devEui.'/activate', self::METHOD_POST, json_encode($parameters));
    }


    private function needToActivate($activation, $devAddr, $appSKey, $nwkSKey)
    {
        return strtoupper($activation['deviceActivation']['appSKey']) != strtoupper($appSKey) ||
            strtoupper($activation['deviceActivation']['devAddr']) != strtoupper($devAddr) ||
            strtoupper($activation['deviceActivation']['fNwkSIntKey']) != strtoupper($nwkSKey) ||
            strtoupper($activation['deviceActivation']['nwkSEncKey']) != strtoupper($nwkSKey) ||
            strtoupper($activation['deviceActivation']['sNwkSIntKey']) != strtoupper($nwkSKey);
    }


    private function sendHttpRequest($url, $method, $data = null, $canBe404 = false)
    {
        $curl = curl_init();

        if ($curl === false)
        {
            throw new AscueException(AscueError::DATA_EXCHANGE_ERROR, 'Ошибка инициализации CURL');
        }

        curl_setopt($curl, CURLOPT_URL, Config::CHIRPSTACK_ADDR.$url);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($curl, CURLOPT_TIMEOUT, 15);
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Accept: application/json',
                'Grpc-Metadata-Authorization: Bearer '.Config::CHIRPSTACK_TOKEN,
            ]
        );

        if ($data)
        {
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }

        $response = curl_exec($curl);
        $errno = curl_errno($curl);
        $error = curl_error($curl);
        $code = curl_getinfo($curl, CURLINFO_RESPONSE_CODE);

        curl_close($curl);

        if ($errno !== CURLE_OK)
        {
            throw new AscueException(AscueError::DATA_EXCHANGE_ERROR, 'Ошибка при выполнении запроса CURL: ' . $error);
        }
        if ($code === 200 || ($canBe404 && $code === 404))
        {
            return [
                'code' => $code,
                'response' => $response,
            ];
        }

        throw new AscueException(AscueError::DATA_EXCHANGE_ERROR, "Принят код состояния HTTP $code\n$response");
    }
}
