<?php

class PGroup
{
    public $parameters = [];

    public function isParameterExists($parameterId)
    {
        foreach ($this->parameters as $parameter)
        {
            if ($parameter->id == $parameterId)
            {
                return true;
            }
        }

        return false;
    }

    public function getParameter($parameterId)
    {
        foreach ($this->parameters as $parameter)
        {
            if ($parameter->id == $parameterId)
            {
                return $parameter;
            }
        }

        return;
    }

    public function getParameterValue($parameterId)
    {
        if ($parameter = $this->getParameter($parameterId))
        {
            return $parameter->value;
        }

        return;
    }

    public function setParameterValue($parameterId, $value)
    {
        foreach ($this->parameters as &$parameter)
        {
            if ($parameter->id == $parameterId)
            {
                $parameter->value = $value;
                return;
            }
        }

        $this->parameters[] = new Parameter($parameterId, $value);
    }
}
