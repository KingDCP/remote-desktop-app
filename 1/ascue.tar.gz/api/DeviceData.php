<?php

class DeviceData
{
    public $externalId;
    public $externalUspdId;
    public $classId;
    public $connClassId;
    public $timezone;
    public $pgroups = [];
}
