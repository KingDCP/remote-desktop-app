#!/usr/bin/php
<?php

require_once('Statistics.php');

if (count($argv) < 2)
{
    return;
}

$method = 'get' . ucfirst($argv[1]);

if (method_exists('Statistics', $method))
{
    echo Statistics::$method();
}
