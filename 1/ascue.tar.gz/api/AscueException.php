<?php

require_once('AscueError.php');

class AscueException extends Exception
{
    public function __construct($code, $message = '')
    {
        $message = AscueError::getErrorString($code) . ': ' . $message;
        parent::__construct($message, $code);
    }
}