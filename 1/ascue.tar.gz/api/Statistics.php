<?php

require_once('Db.php');

class Statistics
{
    private static function exec($sql)
    {
        try
        {
            Db::init();
            Db::query($sql);
            $rows = Db::getAssocAll();

            return $rows[0]['count'];
        }
        catch (PDOException $e)
        {
        }
    }

    public static function getRequestsPerHour()
    {
        $sql = "
        SELECT
            count(*) AS count
        FROM
            request
        WHERE
            task_id IS NOT NULL AND
            time_end > now() - INTERVAL '1 hour'";

        return self::exec($sql);
    }

    public static function getErrorsPerHour()
    {
        $sql = "
        SELECT
            count(*)
        FROM (
            SELECT DISTINCT
                request.id
            FROM
                request,
                unnest(parameters) p
            WHERE
                task_id IS NOT NULL AND
                time_end > now() - INTERVAL '1 hour' AND
                p.id = 1 AND
                p.value != '0'
        ) t";

        return self::exec($sql);
    }

    public static function getDeviceCount()
    {
        $sql = "
        SELECT
            count(*)
        FROM
            device
        WHERE
            NOT deleted";

        return self::exec($sql);
    }
}
