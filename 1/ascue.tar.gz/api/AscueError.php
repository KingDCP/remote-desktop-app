<?php

class AscueError
{
    const OK = 0;                                   // ОК

    const UNKNOWN_CMD = 1;                          // Некорректная команда
    const DB_ERROR = 2;                             // Ошибка при обращении к БД

    const XML_ERROR = 100;                          // Ошибка парсинга XML
    const UNCORRECT_REQUEST = 101;                  // Некорректный запрос
    const DATA_EXCHANGE_ERROR = 102;                // Ошибка обмена данными между частями АСКУЭ
    const UNKNOWN_TASK = 109;                       // Неизвестное задание
    const UNKNOWN_DEVICE = 110;                     // Неизветный девайс
    const UNKNOWN_CONNECTION_CLASS = 111;           // неизвестный класс соединения
    const UNKNOWN_DEVICE_CLASS = 112;               // неизвестный класс девайса

    const CONNECTION_NOT_DEFINED = 120;             // не определено соединение
    const DEVICE_NOT_DEFINED = 121;                 // не определено устройство для опроса

    const UNCORRECT_PARAMETER = 130;                // не корректые / неполные параметры
    const UNCORRECT_CONNECTION_PARAMETER = 131;     // не корректные / не полные параметры соединения
    const UNCORRECT_DEVICE_PARAMETER = 132;         // не корректные / не полные параметры девайса
    const UNSUPPORTED_PARAMETER = 133;              // неподдерживаемый параметр

    const CONNECTION_PORT_NOT_OPENED = 10000;       // не удалось открыть порт
    const CONNECTION_READ_ERROR = 10001;            // ошибка чтения (получения данных)
    const CONNECTION_WRITE_ERROR = 10002;           // ошибка записи (отправления данных)

    const CONNECTION_MODEM_NOT_ANSWERED = 10010;    // модем не ответил
    const MODEM_NOT_SEND_OK = 10011;                // модем не прислал ОК
    const MODEM_NOT_CONNECTED = 10012;              // модем не подключился

    const DEVICE_PORT_NOT_OPENED = 20000;           // попытка опроса счечика через неоткрытое соединение
    const DEVICE_SEND_ERROR = 20001;                // не удалось отправить команду счетчику
    const DEVICE_NOT_ANSWERED = 20002;              // счетчик не ответил
    const DEVICE_UNCORRECT_PACKAGE_SIZE = 20003;    // некорректный размер пакета
    const DEVICE_CRC_ERROR = 20004;                 // ошибка контрольной суммы
    const DEVICE_UNCORRECT_ANSWER = 20005;          // некорректный ответ
    const DEVICE_DEVICE_ERROR = 20006;              // устройство прислало код ошибки


    /**
     * Функция возвращает сообщение об ошибке по ее коду
    **/
    public static function getErrorString($code)
    {
        $errors = array(
            self::OK => 'ОК',
            self::UNKNOWN_CMD => 'Некорректная команда',
            self::DB_ERROR => 'Ошибка БД',

            self::XML_ERROR => 'Ошибка разбора XML',
            self::UNCORRECT_REQUEST => 'Некорректный запрос',
            self::DATA_EXCHANGE_ERROR => 'Ошибка обмена данными',
            self::UNKNOWN_DEVICE => 'Неизвестное устройство',
            self::UNKNOWN_CONNECTION_CLASS => 'Неизвестное устройство связи',
            self::UNKNOWN_DEVICE_CLASS => 'Неизвестный счетчик',

            self::CONNECTION_NOT_DEFINED => 'Соединение не определено',
            self::DEVICE_NOT_DEFINED => 'Счетчик не определен',

            self::UNCORRECT_PARAMETER => 'Переданы некорректные или неполные параметры',
            self::UNCORRECT_CONNECTION_PARAMETER => 'Переданы некорректные или неполные параметры соединения',
            self::UNCORRECT_DEVICE_PARAMETER => 'Переданы некорректные или неполные параметры счетчика',
            self::UNSUPPORTED_PARAMETER => 'Неподдерживаемый параметр',

            self::CONNECTION_PORT_NOT_OPENED => 'Не удалось открыть порт',
            self::CONNECTION_READ_ERROR => 'Ошибка передачи данных',
            self::CONNECTION_WRITE_ERROR => 'Ошибка приема данных',

            self::CONNECTION_MODEM_NOT_ANSWERED => 'Модем не отвечает',
            self::MODEM_NOT_SEND_OK => 'Модем не ответил OK',
            self::MODEM_NOT_CONNECTED => 'Не удалось установить соединение',

            self::DEVICE_PORT_NOT_OPENED => 'Попытка опроса счетчика через неоткрытое соединение',
            self::DEVICE_SEND_ERROR => 'Ошибка передачи данных',
            self::DEVICE_NOT_ANSWERED => 'Счетчик не отвечает',
            self::DEVICE_UNCORRECT_PACKAGE_SIZE => 'Некорректный размер принятого пакета',
            self::DEVICE_CRC_ERROR => 'Ошибка контрольной суммы',
            self::DEVICE_UNCORRECT_ANSWER => 'Некорректный ответ',
            self::DEVICE_DEVICE_ERROR => 'Счетчик прислал код ошибки',
        );

        if (array_key_exists($code, $errors))
        {
            return $errors[$code];
        }

        return 'Неизвестная ошибка';
    }
}

?>
