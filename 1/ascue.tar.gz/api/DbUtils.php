<?php

require_once('Db.php');

class DbUtils
{
    public static function createParametersArray($parameters)
    {
        $parts = [];

        foreach ($parameters as $parameter)
        {
            $parts[] = '"(' . self::createArrayValue($parameter->id) . ',' . 
                self::createArrayValue($parameter->value) . ')"';
        }

        return Db::quote('{' . implode(',', $parts) . '}');
    }

    public static function createArray($arr)
    {
        $parts = [];

        foreach ($arr as $value)
        {
            $parts[] = self::createArrayValue($value);
        }

        return Db::quote('{' . implode(',', $parts) . '}');
    }

    private function createArrayValue($value)
    {
        $count = 0;

        // ' -> '' заменит Db::quote
        $result = str_replace(
            [
                '\\',
                '"',
            ],
            [
                '\\\\\\\\',
                '\"\"',
            ],
            $value,
            $count
        );

        if (!$count &&
            strpos($result, ',') === false &&
            strpos($result, '(') === false &&
            strpos($result, ')') === false &&
            strpos($result, ' ') === false)
        {
            return $result;
        }

        return '\"' . $result . '\"';
    }
}
