<?php

require_once('Config.php');
require_once('DbArrayParser.php');

class Db
{
    private static $conn = NULL;
    private static $sth = NULL;

    /**
     * Подключается к СУБД, выбирает рабочюю базу и кодировку
     * Если подключение уже установлено, не ваполняет никаких действий
    **/
    public static function init()
    {
        if (self::$conn)
        {
            // Подключение было выполнено
            return;
        }

        self::$conn = new PDO(
        'pgsql:host='.Config::PG_SERVER.';'.
        'dbname='.Config::PG_DATABASE.';'.
        'user='.Config::PG_USER.';'.
        'password='.Config::PG_PASSWORD);

        // Включаем режим с исключениями
        self::$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        self::$conn->query("SET NAMES 'UTF8'");
    }

    public static function quote($value)
    {
        return self::$conn->quote($value);
    }

    /**
     * Выполняет запрос с параметрами к БД
    **/
    public static function queryParams($statement, $params)
    {
        self::$sth = self::$conn->prepare($statement);
        self::$sth->execute($params);
    }

    /**
     * Выполняет запрос к БД
    **/
    public static function query($statement)
    {
        self::$sth = self::$conn->query($statement);
    }

    /**
     * Возвращает результаты выполнения запроса в виде ассоциативного массива
    **/
    public function getAssocAll()
    {
        return self::$sth->fetchAll(PDO::FETCH_ASSOC);
    }

    public function beginTransaction()
    {
        self::$conn->beginTransaction();
    }

    public function commit()
    {
        self::$conn->commit();
    }

    public function rollback()
    {
        self::$conn->rollback();
    }

    public function rollbackIfInTransaction()
    {
        if (self::$conn && self::$conn->inTransaction())
        {
            self::$conn->rollback();
        }
    }
}
