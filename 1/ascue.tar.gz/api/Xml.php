<?php

require_once('Parameter.php');
require_once('PGroup.php');
require_once('DeviceData.php');
require_once('RequestData.php');

class Xml
{
    private $xmlDoc;

    public function parse($xmlString)
    {
        $document = new DOMDocument();

        // NOTE убираем определение XML
        // если не убрать, то не везде работает (судя по всему не работает на старом PHP)
        $xmlString = preg_replace("/^\s*<\?.+\?>/i", '', $xmlString);

        if (!$document->loadXML($xmlString))
        {
            // ошибка
            return false;
        }

        $root = $document->documentElement;
        $nodes = $root->childNodes;

        foreach($nodes as $key => $node)
        {
            if ($node->nodeType == XML_ELEMENT_NODE)
            {
                if ($node->nodeName == 'request')
                {
                    return $this->parseRequest($node);
                }
            }
        }
    }

    private function parseRequest($node)
    {
        $requestData = new RequestData();
        $nodes = $node->childNodes;

        foreach($nodes as $key => $node)
        {
            if ($node->nodeType == XML_ELEMENT_NODE)
            {
                switch ($node->nodeName)
                {
                case 'id':
                    $requestData->id = $node->nodeValue;
                    break;
                case 'externalTaskId':
                    $requestData->externalId = $node->nodeValue;
                    break;
                case 'type':
                    $requestData->type = $node->nodeValue;
                    break;
                case 'time':
                    $requestData->time = $node->nodeValue;
                    break;
                case 'device':
                    $requestData->device = $this->parseDevice($node);
                    break;
                }
            }
        }

        return $requestData;
    }

    private function parseDevice($node)
    {
        $deviceData = new DeviceData();
        $nodes = $node->childNodes;

        foreach($nodes as $key => $node)
        {
            if ($node->nodeType == XML_ELEMENT_NODE)
            {
                switch ($node->nodeName)
                {
                case 'externalId':
                    $deviceData->externalId = $node->nodeValue;
                    break;
                case 'externalUspdId':
                    $deviceData->externalUspdId = $node->nodeValue;
                    break;
                case 'classId':
                    $deviceData->classId = $node->nodeValue;
                    break;
                case 'connClassId':
                    $deviceData->connClassId = $node->nodeValue;
                    break;
                case 'timezone':
                    $deviceData->timezone = $node->nodeValue;
                    break;
                case 'pgroup':
                    $deviceData->pgroups[] = $this->parsePGroup($node);
                    break;
                }
            }
        }

        return $deviceData;
    }

    private function parsePGroup($node)
    {
        $pgroup = new PGroup();
        $nodes = $node->childNodes;

        foreach($nodes as $key => $node)
        {
            if ($node->nodeType == XML_ELEMENT_NODE)
            {
                switch ($node->nodeName)
                {
                case 'parameter':
                    $pgroup->parameters[] = $this->parseParameter($node);
                    break;
                }
            }
        }

        return $pgroup;
    }

    private function parseParameter($node)
    {
        $id;
        $value = '';
        $nodes = $node->childNodes;

        foreach($nodes as $key => $node)
        {
            if ($node->nodeType == XML_ELEMENT_NODE)
            {
                switch ($node->nodeName)
                {
                case 'id':
                    $id = $node->nodeValue;
                    break;
                case 'value':
                    $value = $node->nodeValue;
                    break;
                }
            }
        }

        return new Parameter($id, $value);
    }


    /**
     * Формирует XML с ошибкой
    **/
    public function createErrorXml($errorCode)
    {
        $xml = new DomDocument('1.0','utf-8');
        $xml->formatOutput = true;
        $root = $xml->appendChild($xml->createElement('xml'));
        $requestNode = $root->appendChild($xml->createElement('request'));
        $errorNode = $requestNode->appendChild($xml->createElement('error'));
        $errorNode->appendChild($xml->createTextNode($errorCode));
        return $xml->saveXML();
    }


    /**
     * Формирует XML
    **/
    public function createXml($requests)
    {
        $this->xmlDoc = new DomDocument('1.0','utf-8');
        $this->xmlDoc->formatOutput = true;
        $root = $this->xmlDoc->appendChild($this->xmlDoc->createElement('xml'));

        foreach($requests as $request)
        {
            $requestNode = $root->appendChild($this->xmlDoc->createElement('request'));

            $this->appendTextNode($requestNode, 'id', $request->id);
            $this->appendTextNode($requestNode, 'externalTaskId', $request->externalId);
            $this->appendTextNode($requestNode, 'type', $request->type);
            $this->appendTextNode($requestNode, 'time', $request->time);

            $deviceNode = $requestNode->appendChild($this->xmlDoc->createElement('device'));

            $this->appendTextNode($deviceNode, 'externalId', $request->device->externalId);

            foreach($request->device->pgroups as $pgroup)
            {
                $pgroupNode = $deviceNode->appendChild($this->xmlDoc->createElement('pgroup'));

                foreach($pgroup->parameters as $parameter)
                {
                    $parameterNode = $pgroupNode->appendChild($this->xmlDoc->createElement('parameter'));
                    $this->appendTextNode($parameterNode, 'id', $parameter->id);
                    $this->appendTextNode($parameterNode, 'value', $parameter->value);
                }
            }
        }

        return $this->xmlDoc->saveXML();
    }

    /**
     * добавляет текстовый узел в XML
    **/
    private function appendTextNode($parentNode, $nodeName, $nodeValue)
    {
        if (!is_null($nodeValue) && strlen($nodeValue) != 0)
        {
            $node = $parentNode->appendChild($this->xmlDoc->createElement($nodeName));
            $node->appendChild($this->xmlDoc->createTextNode($nodeValue));
        }
    }
}
