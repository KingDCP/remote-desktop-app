<?php

require_once('AscueException.php');

class DbDataException extends AscueException
{
    public function __construct()
    {
        parent::__construct(AscueError::DB_ERROR);
    }
}
