<?php

require_once('AscueException.php');
require_once('Parameter.php');
require_once('WebSocket.php');
require_once('Config.php');

class IotVegaServerApi
{
    const DELAY_RX1 = 5;

    private $ws;

    public function sync($device)
    {
        $pgroup = $device->pgroups[0];

        if (!$pgroup->isParameterExists(Parameter::LORA_DEV_EUI_S))
        {
            // если нет devEui, то это не устройство LoRaWAN
            return;
        }

        if (!$pgroup->isParameterExists(Parameter::LORA_APP_KEY_S) ||
            !$pgroup->isParameterExists(Parameter::LORA_DEVICE_CLASS) ||
            !$pgroup->isParameterExists(Parameter::LORA_GROUP_NAME))
        {
            throw new AscueException(AscueError::UNCORRECT_PARAMETER, 'Переданы не все параметры');
        }

        // параметры для ABP должны или отсутвовать или присутствовать все сразу
        $hasDevAddress = $pgroup->isParameterExists(Parameter::LORA_DEV_ADDR_S);
        $hasAppsKey = $pgroup->isParameterExists(Parameter::LORA_APP_S_KEY_S);
        $hasNwksKey = $pgroup->isParameterExists(Parameter::LORA_NWK_S_KEY_S);

        if (($hasDevAddress || $hasAppsKey || $hasNwksKey) &&
            !($hasDevAddress && $hasAppsKey && $hasNwksKey))
        {
            throw new AscueException(AscueError::UNCORRECT_PARAMETER, 'Переданы не все параметры ABP');
        }

        $devParams = [
            'devEui' => $pgroup->getParameterValue(Parameter::LORA_DEV_EUI_S),
            'appKey' => $pgroup->getParameterValue(Parameter::LORA_APP_KEY_S),
            'class' => 'CLASS_'.strtoupper($pgroup->getParameterValue(Parameter::LORA_DEVICE_CLASS)),
            'group' => $pgroup->getParameterValue(Parameter::LORA_GROUP_NAME),
        ];

        if ($hasDevAddress)
        {
            $devParams['devAddress'] = $pgroup->getParameterValue(Parameter::LORA_DEV_ADDR_S);
            $devParams['appsKey'] = $pgroup->getParameterValue(Parameter::LORA_APP_S_KEY_S);
            $devParams['nwksKey'] = $pgroup->getParameterValue(Parameter::LORA_NWK_S_KEY_S);
        }

        if (!$this->connect())
        {
            throw new AscueException(AscueError::DATA_EXCHANGE_ERROR, 'Ошибка подключения к IoT Vega Server');
        }

        $result = $this->proceed($devParams);
        $this->close();

        if (!$result)
        {
            throw new AscueException(AscueError::DATA_EXCHANGE_ERROR, 'Ошибка при добавлении усройства в IoT Vega Server');
        }
    }

    private function proceed($devParams)
    {
        $dParams = $this->getDeviceParameters($devParams['devEui']);

        if ($dParams === false)
        {
            // ошибка при получении информации об устройстве
            return false;
        }

        if ($dParams !== null)
        {
            // есть устройство
            $abpParamsEqual =
                (!isset($devParams['devAddress']) && !isset($dParams['devAddress'])) ||
                (
                    isset($devParams['devAddress']) && isset($dParams['devAddress']) &&
                    hexdec($devParams['devAddress']) == $dParams['devAddress'] &&
                    strtoupper($devParams['appsKey']) == strtoupper($dParams['appsKey']) &&
                    strtoupper($devParams['nwksKey']) == strtoupper($dParams['nwksKey'])
                );

            if (strtoupper($devParams['appKey']) == strtoupper($dParams['appKey']) &&
                strtoupper($devParams['class']) == strtoupper($dParams['class']) &&
                $abpParamsEqual
            )
            {
                if ($dParams['delayRx1'] != self::DELAY_RX1)
                {
                    // меняем delayRx1
                    return $this->changeDelayRx1($devParams);
                }

                // настройки менять не надо
                return true;
            }

            if ($dParams['lastJoinTs'])
            {
                // устройство выходило на связь, удалять нельзя
                return false;
            }

            if (!$this->deleteDevice($devParams['devEui']))
            {
                // ошибка при удалении устройства
                return false;
            }
        }

        if (!$this->addDevice($devParams))
        {
            // ошибка при добавлении устройства
            return false;
        }

        if (!$this->addGroup($devParams['devEui'], $devParams['group']))
        {
            // ошибка при добавлении группы устройства
            return false;
        }

        return true;
    }

    private function connect()
    {
        $this->ws = new WebSocket();

        if (!$this->ws->connect(Config::VEGA_ADDR, Config::VEGA_PORT))
        {
            return false;
        }

        $authReq = [
            'cmd' => 'auth_req',
            'login' => Config::VEGA_LOGIN,
            'password' => Config::VEGA_PASSWORD,
        ];

        $authResp = $this->ws->send(json_encode($authReq));

        if ($authResp === false)
        {
            return false;
        }

        $authResp = json_decode($authResp);

        if ($authResp === null)
        {
            return false;
        }

        if (!isset($authResp->status) || !$authResp->status)
        {
            return false;
        }

        return true;
    }

    private function close()
    {
        $this->ws->close();
    }

    private function getDeviceParameters($devEui)
    {
        $req = [
            'cmd' => 'get_devices_req',
            'select' => [
                'devEui_list' => [
                    $devEui,
                ]
            ],
        ];

        $resp = $this->ws->send(json_encode($req));

        if ($resp === false)
        {
            return false;
        }

        $resp = json_decode($resp);

        if ($resp === null)
        {
            return false;
        }

        if (!isset($resp->status) || !$resp->status)
        {
            // команда выполнена неуспешно
            return false;
        }

        if (!isset($resp->devices_list))
        {
            // не возвращен список устройств
            return false;
        }

        if (!count($resp->devices_list))
        {
            // пустой список
            return null;
        }

        if (!isset($resp->devices_list[0]->OTAA->appKey) ||
            !isset($resp->devices_list[0]->OTAA->last_join_ts) ||
            !isset($resp->devices_list[0]->class) ||
            !isset($resp->devices_list[0]->delayRx1))
        {
            // нет параметров
            return false;
        }

        $devParams = [
            'appKey' => $resp->devices_list[0]->OTAA->appKey,
            'lastJoinTs' => $resp->devices_list[0]->OTAA->last_join_ts,
            'class' => $resp->devices_list[0]->class,
            'delayRx1' => $resp->devices_list[0]->delayRx1,
        ];

        if (isset($resp->devices_list[0]->ABP->devAddress))
        {
            $devParams['devAddress'] = $resp->devices_list[0]->ABP->devAddress;
        }
        if (isset($resp->devices_list[0]->ABP->appsKey))
        {
            $devParams['appsKey'] = $resp->devices_list[0]->ABP->appsKey;
        }
        if (isset($resp->devices_list[0]->ABP->nwksKey))
        {
            $devParams['nwksKey'] = $resp->devices_list[0]->ABP->nwksKey;
        }

        return $devParams;
    }

    private function addDevice($devParams)
    {
        $req = [
            'cmd' => 'manage_devices_req',
            'devices_list' => [
                [
                    'devEui' => $devParams['devEui'],
                    'OTAA' => [
                        'appKey' => $devParams['appKey'],
                    ],
                    'class' => $devParams['class'],
                    'rxWindow' => 1,
                    'delayRx1' => self::DELAY_RX1,
                    'delayJoin1' => 5,
                    'drRx2' => 0,
                    'preferDr' => 5,
                    'preferPower' => 14,
                    'reactionTime' => 1000,
                    'serverAdrEnabled' => true,
                ],
            ],
        ];

        if (isset($devParams['devAddress']))
        {
            $req['devices_list'][0]['ABP']['devAddress'] = hexdec($devParams['devAddress']);
            $req['devices_list'][0]['ABP']['appsKey'] = $devParams['appsKey'];
            $req['devices_list'][0]['ABP']['nwksKey'] = $devParams['nwksKey'];
        }

        if (in_array($devParams['group'], Config::VEGA_EU868_GROUPS))
        {
            $req['devices_list'][0]['devName'] = $devParams['devEui'].'_E';
            $req['devices_list'][0]['frequencyPlan'] = [
                'freq4' => 867100000,
                'freq5' => 867300000,
                'freq6' => 867500000,
                'freq7' => 867700000,
                'freq8' => 867900000,
            ];
            $req['devices_list'][0]['freqRx2'] = 869525000;
        }
        elseif (in_array($devParams['group'], Config::VEGA_KZ865_GROUPS))
        {
            $req['devices_list'][0]['devName'] = $devParams['devEui'].'_KZ';
            $req['devices_list'][0]['frequencyPlan'] = [
                'freq4' => 867100000,
                'freq5' => 867300000,
                'freq6' => 867500000,
                'freq7' => 867700000,
                'freq8' => 867900000,
            ];
            $req['devices_list'][0]['freqRx2'] = 867500000;
        }
        elseif (in_array($devParams['group'], Config::VEGA_LARTECH_GROUPS))
        {
            $req['devices_list'][0]['devName'] = $devParams['devEui'].'_LT';
            $req['devices_list'][0]['frequencyPlan'] = [
                'freq4' => 867100000,
                'freq5' => 867300000,
                'freq6' => 867500000,
                'freq7' => 867700000,
                'freq8' => 867900000,
            ];
            $req['devices_list'][0]['freqRx2'] = 869100000;
        }
        else
        {
            $req['devices_list'][0]['devName'] = $devParams['devEui'];
            $req['devices_list'][0]['frequencyPlan'] = [
                'freq4' => 864100000,
                'freq5' => 864300000,
                'freq6' => 864500000,
                'freq7' => 864700000,
                'freq8' => 864900000,
            ];
            $req['devices_list'][0]['freqRx2'] = 869100000;
        }

        $resp = $this->ws->send(json_encode($req));

        if ($resp === false)
        {
            return false;
        }

        $resp = json_decode($resp);

        if ($resp === null)
        {
            return false;
        }

        if (!isset($resp->status) || !$resp->status)
        {
            // команда выполнена неуспешно
            return false;
        }

        if (!isset($resp->device_add_status) || !count($resp->device_add_status))
        {
            // не возвращен список статусов или он пустой
            return false;
        }

        if (!isset($resp->device_add_status[0]->status) || $resp->device_add_status[0]->status != 'added')
        {
            // нет поля status, или статус не "added"
            return false;
        }

        return true;
    }

    private function changeDelayRx1($devParams)
    {
        $req = [
            'cmd' => 'manage_devices_req',
            'devices_list' => [
                [
                    'devEui' => $devParams['devEui'],
                    'delayRx1' => self::DELAY_RX1,
                ],
            ],
        ];

        $resp = $this->ws->send(json_encode($req));

        if ($resp === false)
        {
            return false;
        }

        $resp = json_decode($resp);

        if ($resp === null)
        {
            return false;
        }

        if (!isset($resp->status) || !$resp->status)
        {
            // команда выполнена неуспешно
            return false;
        }

        if (!isset($resp->device_add_status) || !count($resp->device_add_status))
        {
            // не возвращен список статусов или он пустой
            return false;
        }

        if (!isset($resp->device_add_status[0]->status) || $resp->device_add_status[0]->status != 'updated')
        {
            // нет поля status, или статус не "updated"
            return false;
        }

        return true;
    }

    private function addGroup($devEui, $group)
    {
        $req = [
            'cmd' => 'manage_device_appdata_req',
            'data_list' => [
                [
                    'devEui' => $devEui,
                    'group' => $group,
                ]
            ],
        ];

        $resp = $this->ws->send(json_encode($req));

        if ($resp === false)
        {
            return false;
        }

        $resp = json_decode($resp);

        if ($resp === null)
        {
            return false;
        }

        if (!isset($resp->status) || !$resp->status)
        {
            // команда выполнена неуспешно
            return false;
        }

        if (!isset($resp->update_status) || !count($resp->update_status))
        {
            // не возвращен список статусов или он пустой
            return false;
        }

        if (!isset($resp->update_status[0]->status) || !$resp->update_status[0]->status)
        {
            // нет поля status, или статус не успешный
            return false;
        }

        return true;
    }

    private function deleteDevice($devEui)
    {
        $req = [
            'cmd' => 'delete_devices_req',
            'devices_list' => [
                $devEui,
            ],
        ];

        $resp = $this->ws->send(json_encode($req));

        if ($resp === false)
        {
            return false;
        }

        $resp = json_decode($resp);

        if ($resp === null)
        {
            return false;
        }

        if (!isset($resp->status) || !$resp->status)
        {
            // команда выполнена неуспешно
            return false;
        }

        if (!isset($resp->device_delete_status) || !count($resp->device_delete_status))
        {
            // не возвращен список статусов или он пустой
            return false;
        }

        if (!isset($resp->device_delete_status[0]->status) || $resp->device_delete_status[0]->status != 'deleted')
        {
            // нет поля status, или статус не "deleted"
            return false;
        }

        return true;
    }
}
