<?php

class RequestData
{
    public $id;
    public $externalId;
    public $type;
    public $time;
    public $device;
}
