<?php

require_once('AscueException.php');

class Schedule
{
    public $timeInterval;
    public $timeValues = [];
    public $days = [];
    public $daysOfWeek = [];

    public function parse($schedule)
    {
        // Разделим на части по пробелам
        $scheduleElements = explode(' ', trim($schedule));
        $dateElement = 2;   // начальный элемент даты

        if (count($scheduleElements) != 4 && count($scheduleElements) != 5)
        {
            throw new AscueException(AscueError::UNCORRECT_REQUEST, 'Некорректное расписание');
        }

        // Парсим время
        if (count($scheduleElements) == 4)
        {
            // выражение вида (HH:mm-HH:mm)/HH:mm * * *
            $dateElement = 1;

            // распарсим время
            $matches = [];

            if (!preg_match('/^\((\d{2}):(\d{2})-(\d{2}):(\d{2})\)\/(\d{2}):(\d{2})$/', $scheduleElements[0], $matches))
            {
                throw new AscueException(AscueError::UNCORRECT_REQUEST, 'Некорректное расписание');
            }

            $this->timeValues[] = $matches[1] * 60 + $matches[2];
            $this->timeValues[] = $matches[3] * 60 + $matches[4];
            $this->timeInterval = $matches[5] * 60 + $matches[6];
        }
        else
        {
            // выражение mm HH * * *
            $this->timeValues[] = $scheduleElements[1] * 60 + $scheduleElements[0];
        }

        // Парсим дату
        if ($scheduleElements[$dateElement] == '*' && $scheduleElements[$dateElement + 1] == '*' && $scheduleElements[$dateElement + 2] == '*')
        {
            // ежедневно
            return;
        }
        elseif ($scheduleElements[$dateElement] == '*' && $scheduleElements[$dateElement + 1] == '*')
        {
            // еженедельно
            $this->daysOfWeek = explode(',', $scheduleElements[$dateElement + 2]);
        }
        elseif ($scheduleElements[$dateElement + 1] == '*' && $scheduleElements[$dateElement + 2] == '*')
        {
            // ежемесячно
            $this->days = explode(',', $scheduleElements[$dateElement]);
        }
    }
}
