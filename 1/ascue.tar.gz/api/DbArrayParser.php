<?php

require_once('DbDataException.php');
require_once('PGroup.php');
require_once('Parameter.php');

class DbArrayParser
{
    private $str;
    private $pos;
    private $length;

    public function parse($arrayStr)
    {
        $this->str = $arrayStr;
        $this->length = strlen($this->str);
        $this->pos = 1;

        // { - начало массива
        if ($this->length < 1 || $this->str[0] != '{')
        {
            throw new DbDataException();
        }

        $data = [];
        $pgroup = new PGroup();
        $n = 0;

        while (1)
        {
            $p = $this->parseParameter();

            if ($p->isDelimiter())
            {
                $data[] = $pgroup;
                $pgroup = new PGroup();
            }
            else
            {
                $pgroup->parameters[] = $p;
            }

            if ($this->length < $this->pos + 2)
            {
                throw new DbDataException();
            }
            if ($this->str[$this->pos + 1] == '}')
            {
                // } - конец массива
                break;
            }
            // , - разделитель элементов
            if ($this->length < $this->pos + 3 || $this->str[$this->pos + 1] != ',')
            {
                throw new DbDataException();
            }

            $this->pos += 2;
        }

        if ($pgroup->parameters)
        {
            $data[] = $pgroup;
        }

        return $data;
    }

    private function parseParameter()
    {
        // "( - начало параметра
        if ($this->length < $this->pos + 3 || $this->str[$this->pos] != '"' || $this->str[$this->pos + 1] != '(')
        {
            throw new DbDataException();
        }

        $this->pos += 2;

        $id = $this->parseValue();
        
        if (!is_numeric($id))
        {
            throw new DbDataException();
        }

        // , - разделитель элементов в параметре
        if ($this->length < $this->pos + 3 || $this->str[$this->pos + 1] != ',')
        {
            throw new DbDataException();
        }

        $this->pos += 2;
        $value = $this->parseValue();

        // )" - нонец параметра
        if ($this->length < $this->pos + 3 || $this->str[$this->pos + 1] != ')' || $this->str[$this->pos + 2] != '"')
        {
            throw new DbDataException();
        }

        $this->pos += 2;

        return new Parameter($id, $value);
    }


    private function parseValue()
    {
        $value = "";
        $quoted = false;

        if ($this->str[$this->pos] == '\\')
        {
            // значение может быть в двойных кавычках, они должны быть экранированы
            if ($this->length < $this->pos + 3 || $this->str[$this->pos + 1] != '"')
            {
                throw new DbDataException();
            }

            $quoted = true;
            $this->pos += 2;
        }

        while (1)
        {
            if (($this->str[$this->pos] == ',' || $this->str[$this->pos] == ')') && !$quoted)
            {
                // , или ) - стоит после конца значения
                $this->pos--;
                return $value;
            }

            if ($this->str[$this->pos] == '\\')
            {
                if (!$quoted)
                {
                    // обратный слэш может быть только, если значение в кавычках
                    throw new DbDataException();
                }

                if ($this->length < $this->pos + 3)
                {
                    throw new DbDataException();
                }

                if ($this->str[$this->pos + 1] == '"' && ($this->str[$this->pos + 2] == ',' || $this->str[$this->pos + 2] == ')'))
                {
                    // \", или \")- конец значения в кавычках
                    $this->pos++;
                    return $value;
                }

                if ($this->length < $this->pos + 5)
                {
                    throw new DbDataException();
                }

                if ($this->str[$this->pos + 1] == '\\' && $this->str[$this->pos + 2] == '\\' && $this->str[$this->pos + 3] == '\\')
                {
                    // \\\\ -> "\"
                    $value .= '\\';
                    $this->pos += 4;
                    continue;
                }

                if ($this->str[$this->pos + 1] == '"' && $this->str[$this->pos + 2] == '\\' && $this->str[$this->pos + 3] == '"')
                {
                    // \"\" -> "
                    $value .= '"';
                    $this->pos += 4;
                    continue;
                }

                throw new DbDataException();
            }

            $value .= $this->str[$this->pos];

            if ($this->length < $this->pos + 2)
            {
                throw new DbDataException();
            }
            $this->pos++;
        }

        return $value;
    }
}
