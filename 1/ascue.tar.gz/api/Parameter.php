<?php

class Parameter
{
    const BEGIN_DATETIME_S = 101;   // начальное время
    const AUTO_DATETIME_UI = 103;   // флаг автоматического изменения интервала времени

    const LORA_GROUP_NAME = 10060;
    const LORA_DEV_EUI_S = 10061;
    const LORA_DEV_ADDR_S = 10062;
    const LORA_APP_KEY_S = 10064;
    const LORA_APP_S_KEY_S = 10065;
    const LORA_NWK_S_KEY_S = 10066;
    const LORA_DEVICE_CLASS = 10067;

    public $id;
    public $value;

    public function __construct($id, $value)
    {
        $this->id = $id;
        $this->value = $value;
    }

    public function isDelimiter()
    {
        return !$this->id;
    }
}
