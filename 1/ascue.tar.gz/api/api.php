<?php

require_once('AscueApi.php');
require_once('AscueError.php');
require_once('AscueException.php');
require_once('Xml.php');

header("Content-Type: text/xml; charset=utf-8");

try
{
    $api = new AscueApi();
    echo $api->proceed();
}
catch (AscueException $e)
{
    echo (new Xml())->createErrorXml($e->getCode());
}
catch (PDOException $e)
{
    echo (new Xml())->createErrorXml(AscueError::DB_ERROR);
}
catch (DOMException $e)
{
    echo (new Xml())->createErrorXml(AscueError::XML_ERROR);
}

?>
