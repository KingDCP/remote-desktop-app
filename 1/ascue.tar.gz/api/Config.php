<?php

class Config
{
    const PG_SERVER = 'localhost';
    const PG_USER = 'login';
    const PG_PASSWORD = 'password';
    const PG_DATABASE = 'ascue';

    const VEGA_ADDR = '127.0.0.1';
    const VEGA_PORT = 8002;
    const VEGA_LOGIN = 'login';
    const VEGA_PASSWORD = 'password';

    const VEGA_EU868_GROUPS = [
    ];
    const VEGA_KZ865_GROUPS = [
    ];
    const VEGA_LARTECH_GROUPS = [
    ];

    const CHIRPSTACK_ADDR = 'http://127.0.0.1:8080';
    const CHIRPSTACK_TOKEN = 'TOKEN';

    const CHIRPSTACK_DEVICE_PROFILE_IDS = [
        1 => [
            'A' => 'UUID_A',
            'C' => 'UUID_B',
            'ABP' => 'UUID_ABP',
        ],
    ];
}
