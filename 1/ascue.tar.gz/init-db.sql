--
-- PostgreSQL database dump
--

-- Dumped from database version 13.10
-- Dumped by pg_dump version 13.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: parameter; Type: TYPE; Schema: public; Owner: ascue
--

CREATE TYPE public.parameter AS (
	id integer,
	value character varying
);


ALTER TYPE public.parameter OWNER TO ascue;

--
-- Name: proceed_schedules(); Type: FUNCTION; Schema: public; Owner: ascue
--

CREATE FUNCTION public.proceed_schedules() RETURNS void
    LANGUAGE sql COST 5
    AS $$UPDATE
    task
SET
    next_execution_time = now(),
    retry_count = 0
FROM device
WHERE
    device.id = task.device_id AND
    device.deleted = FALSE AND
    task.type = 1 AND
    task.state = 1 AND
    (
        (
            -- time_values содержит список времен, когда расписание сработает
            time_interval IS NULL AND
            (EXTRACT(HOUR FROM now() AT TIME ZONE timezone) * 60 + EXTRACT(MINUTE FROM now() AT TIME ZONE timezone)) = ANY (time_values)
        )
        OR
    (
        -- time_values содержит начало и конец диапазона времени, раcписание срабатывает каждые time_interval минут
            time_interval IS NOT NULL AND
            (EXTRACT(HOUR FROM now() AT TIME ZONE timezone) * 60 + EXTRACT(MINUTE FROM now() AT TIME ZONE timezone)) BETWEEN time_values[1] AND time_values[2]
            AND
            ((EXTRACT(HOUR FROM now() AT TIME ZONE timezone) * 60 + EXTRACT(MINUTE FROM now() AT TIME ZONE timezone)) - time_values[1])::smallint % time_interval = 0
        )
    )
    AND
    (
        (
            -- каждый день
        days IS NULL AND
        days_of_week IS NULL
        )
        OR
        (
            days_of_week IS NULL AND
            (
                -- текущий день месяца содержится в массиве
                EXTRACT (DAY FROM now() AT TIME ZONE timezone) = ANY (days)
                OR
                (
                    -- 31 - последние день месяца
                    31::smallint = ANY (days)
                    AND
                    EXTRACT (DAY FROM DATE_TRUNC('month', NOW() AT TIME ZONE timezone) + interval '1 month - 1 day') = EXTRACT (DAY FROM now() AT TIME ZONE timezone)
                )
            )
        )
        OR
        (
            -- срабатывание по дням недели
            days IS NULL AND
            EXTRACT(DOW FROM now() AT TIME ZONE timezone) = ANY (days_of_week)
        )
    )$$;


ALTER FUNCTION public.proceed_schedules() OWNER TO ascue;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: client; Type: TABLE; Schema: public; Owner: ascue
--

CREATE TABLE public.client (
    id integer NOT NULL,
    token character varying NOT NULL
);


ALTER TABLE public.client OWNER TO ascue;

--
-- Name: client_id_seq; Type: SEQUENCE; Schema: public; Owner: ascue
--

CREATE SEQUENCE public.client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.client_id_seq OWNER TO ascue;

--
-- Name: client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ascue
--

ALTER SEQUENCE public.client_id_seq OWNED BY public.client.id;


--
-- Name: device; Type: TABLE; Schema: public; Owner: ascue
--

CREATE TABLE public.device (
    id integer NOT NULL,
    external_id character varying NOT NULL,
    class_id integer,
    conn_class_id integer,
    timezone character varying DEFAULT 'Europe/Moscow'::character varying NOT NULL,
    parameters public.parameter[] NOT NULL,
    client_id integer NOT NULL,
    deleted boolean DEFAULT false NOT NULL,
    uspd_id integer
);


ALTER TABLE public.device OWNER TO ascue;

--
-- Name: device_id_seq; Type: SEQUENCE; Schema: public; Owner: ascue
--

CREATE SEQUENCE public.device_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.device_id_seq OWNER TO ascue;

--
-- Name: device_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ascue
--

ALTER SEQUENCE public.device_id_seq OWNED BY public.device.id;


--
-- Name: request; Type: TABLE; Schema: public; Owner: ascue
--

CREATE TABLE public.request (
    id bigint NOT NULL,
    task_id integer,
    time_end timestamp without time zone,
    parameters public.parameter[],
    client_id integer
);


ALTER TABLE public.request OWNER TO ascue;

--
-- Name: request_id_seq; Type: SEQUENCE; Schema: public; Owner: ascue
--

CREATE SEQUENCE public.request_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.request_id_seq OWNER TO ascue;

--
-- Name: request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ascue
--

ALTER SEQUENCE public.request_id_seq OWNED BY public.request.id;


--
-- Name: task; Type: TABLE; Schema: public; Owner: ascue
--

CREATE TABLE public.task (
    id integer NOT NULL,
    external_id character varying,
    device_id integer NOT NULL,
    parameters public.parameter[] NOT NULL,
    type smallint DEFAULT 1 NOT NULL,
    next_execution_time timestamp without time zone,
    last_execution_time_begin timestamp without time zone,
    last_execution_time_end timestamp without time zone,
    execute_when_connected boolean DEFAULT false NOT NULL,
    retry_count smallint DEFAULT 0 NOT NULL,
    time_interval smallint,
    days smallint[],
    days_of_week smallint[],
    time_values smallint[],
    client_id integer NOT NULL,
    state smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.task OWNER TO ascue;

--
-- Name: task_id_seq; Type: SEQUENCE; Schema: public; Owner: ascue
--

CREATE SEQUENCE public.task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_id_seq OWNER TO ascue;

--
-- Name: task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ascue
--

ALTER SEQUENCE public.task_id_seq OWNED BY public.task.id;


--
-- Name: client id; Type: DEFAULT; Schema: public; Owner: ascue
--

ALTER TABLE ONLY public.client ALTER COLUMN id SET DEFAULT nextval('public.client_id_seq'::regclass);


--
-- Name: device id; Type: DEFAULT; Schema: public; Owner: ascue
--

ALTER TABLE ONLY public.device ALTER COLUMN id SET DEFAULT nextval('public.device_id_seq'::regclass);


--
-- Name: request id; Type: DEFAULT; Schema: public; Owner: ascue
--

ALTER TABLE ONLY public.request ALTER COLUMN id SET DEFAULT nextval('public.request_id_seq'::regclass);


--
-- Name: task id; Type: DEFAULT; Schema: public; Owner: ascue
--

ALTER TABLE ONLY public.task ALTER COLUMN id SET DEFAULT nextval('public.task_id_seq'::regclass);


--
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: ascue
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (id);


--
-- Name: device device_client_id_external_id_key; Type: CONSTRAINT; Schema: public; Owner: ascue
--

ALTER TABLE ONLY public.device
    ADD CONSTRAINT device_client_id_external_id_key UNIQUE (client_id, external_id);


--
-- Name: device device_pkey; Type: CONSTRAINT; Schema: public; Owner: ascue
--

ALTER TABLE ONLY public.device
    ADD CONSTRAINT device_pkey PRIMARY KEY (id);


--
-- Name: request request_pkey; Type: CONSTRAINT; Schema: public; Owner: ascue
--

ALTER TABLE ONLY public.request
    ADD CONSTRAINT request_pkey PRIMARY KEY (id);


--
-- Name: task task_client_id_external_id_key; Type: CONSTRAINT; Schema: public; Owner: ascue
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_client_id_external_id_key UNIQUE (client_id, external_id);


--
-- Name: task task_pkey; Type: CONSTRAINT; Schema: public; Owner: ascue
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: device_conn_class_id_key; Type: INDEX; Schema: public; Owner: ascue
--

CREATE INDEX device_conn_class_id_key ON public.device USING btree (conn_class_id);


--
-- Name: device_parameters_key; Type: INDEX; Schema: public; Owner: ascue
--

CREATE INDEX device_parameters_key ON public.device USING gin (parameters);


--
-- Name: device_uspd_id_key; Type: INDEX; Schema: public; Owner: ascue
--

CREATE INDEX device_uspd_id_key ON public.device USING btree (uspd_id);


--
-- Name: request_client_id_key; Type: INDEX; Schema: public; Owner: ascue
--

CREATE INDEX request_client_id_key ON public.request USING btree (client_id);


--
-- Name: request_time_end_key; Type: INDEX; Schema: public; Owner: ascue
--

CREATE INDEX request_time_end_key ON public.request USING btree (time_end);


--
-- Name: task_device_id_execute_when_connected_key; Type: INDEX; Schema: public; Owner: ascue
--

CREATE INDEX task_device_id_execute_when_connected_key ON public.task USING btree (device_id, execute_when_connected);


--
-- Name: task_type_state_key; Type: INDEX; Schema: public; Owner: ascue
--

CREATE INDEX task_type_state_key ON public.task USING btree (type, state);


--
-- Name: device device_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ascue
--

ALTER TABLE ONLY public.device
    ADD CONSTRAINT device_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: device device_uspd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ascue
--

ALTER TABLE ONLY public.device
    ADD CONSTRAINT device_uspd_id_fkey FOREIGN KEY (uspd_id) REFERENCES public.device(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: request request_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ascue
--

ALTER TABLE ONLY public.request
    ADD CONSTRAINT request_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: request request_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ascue
--

ALTER TABLE ONLY public.request
    ADD CONSTRAINT request_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.task(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: task task_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ascue
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: task task_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ascue
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.device(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO ascue;


--
-- PostgreSQL database dump complete
--

